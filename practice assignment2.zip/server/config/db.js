module.exports = 
{
    //"URI": "mongodb://localhost/contact_list"
    "URI": "mongodb+srv://jihoonlee:<password>@cluster0.ichzz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
}